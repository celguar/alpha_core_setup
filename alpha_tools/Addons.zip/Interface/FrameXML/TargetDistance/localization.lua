-- Version : English - ?????

TARGETDISTANCE_SEP			= "Target Distance Options";
TARGETDISTANCE_SEP_INFO		= "These options involve the indicator displaying the\n distance to your target";
TARGETDISTANCE_CHECK 		= "Show target distance";
TARGETDISTANCE_CHECK_INFO	= "Shows a panel which displays the distance to your target";
TARGETDISTANCE_DISTANCE		= "Distance: %d yds";
