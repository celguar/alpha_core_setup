# EsUI

This AddOn enhances some aspects of the original interface.

- Adds the Talents microbutton.
- Adds a button on the main menu to reload the UI.
- Adds a button to open / close all bags.
- Enables instant quest text.
