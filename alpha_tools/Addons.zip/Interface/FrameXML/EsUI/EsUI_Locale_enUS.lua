----------------------------------------------------------------------------------------
--	English Localization
----------------------------------------------------------------------------------------
EsUI.L = {
	DISBAND_CHAT = "Disbanding group...",
	DISBAND_POPUP = "Are you sure you want to disband the group?",
	SECONDS = "%d seconds",
	MINUTES = "%d minutes",
	HOURS = "%d hours",
	DAYS = "%d days",
	REMAINING = " remaining",
	WELCOME = "Welcome to EsUI v"
}
