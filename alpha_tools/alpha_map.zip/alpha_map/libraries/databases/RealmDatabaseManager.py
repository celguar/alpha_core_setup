# import hashlib
# import os
import yaml

from libraries.utils.Logger import Logger
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session

from libraries.databases import RealmModels
from libraries.utils import Logger

with open('etc/config/config.yaml', 'r') as file:
    config = yaml.safe_load(file)


maps_static_data = config['maps_static_data']
host=config['database']['host']
user = config['database']['user']
password = config['database']['pass']
database = "alpha_realm"
charset = config['database']['charset']

realm_db_engine = create_engine(f'mysql+pymysql://{user}:{password}@{host}/{database}?charset={charset}', pool_pre_ping=True)
SessionHolder = scoped_session(sessionmaker(bind=realm_db_engine, autocommit=False, autoflush=True))


map_id = config['frontend']['map_id']

mapLeftPoint = maps_static_data[map_id]['mapLeftPoint']
mapTopPoint = maps_static_data[map_id]['mapTopPoint']
mapWidth = maps_static_data[map_id]['mapWidth']
mapHeight = maps_static_data[map_id]['mapHeight']
imageWidth = maps_static_data[map_id]['imageWidth']
imageHeight = maps_static_data[map_id]['imageHeight']


class RealmDatabaseManager(object):
    # Realm.
    
    @staticmethod
    def players_online():
        realm_db_session = SessionHolder()
        
        results = realm_db_session.query(
                RealmModels.Character
            ).filter(
                RealmModels.Character.online == '1'
            ).all()
            
        realm_db_session.close()

        return len(results)

    @staticmethod
    def get_player_location(map_id):
        realm_db_session = SessionHolder()

        lst = dict()

        records = realm_db_session.query(
            RealmModels.Character
            ).filter(
                RealmModels.Character.map == map_id,
                RealmModels.Character.online == '1'
            ).all()

        length = len(records)

        for record in records:
            d = {
                'id': record.guid,
                'entry': record.guid,
                'x': record.position_x,
                'y': record.position_y,
                'z': record.position_z,
                'orientation': record.orientation,
                'map': record.map,
                'name': record.name,
                'class': record.class_,
                'race': record.race,
                'gender': record.gender,
                'level': record.level,
                'class_name': 'player'
            }

            print(record.name, record.map, record.online)

            lst[record.guid] = d
            
        realm_db_session.close()

        return lst
